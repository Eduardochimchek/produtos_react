import TabelaProdutos from './components/TabelaProdutos'
import './App.css'

function App() {
  return (
    <>
      <h2>Tabela de Produtos</h2>

      <TabelaProdutos />
    </>
  )
}

export default App