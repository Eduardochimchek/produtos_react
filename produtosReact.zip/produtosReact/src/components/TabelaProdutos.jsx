function TabelaProdutos() {
    const produtos = [
        {id : 1, nome: "Produto A", preco: "50,00", estoque: 20},
        {id : 2, nome: "Produto B", preco: "35,00", estoque: 20},
        {id : 3, nome: "Produto C", preco: "40,00", estoque: 30},
    ]

    return( 
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Preço</th>
                    <th>Estoque (kg)</th>
                    <th style={{textAlign: "center"}}>Ações</th>
                </tr>
            </thead>
            <tbody>
                {produtos.map((prod) => (
                    <tr key={prod.id}>
                        <td>{prod.id}</td>
                        <td>{prod.nome}</td>
                        <td>R$ {prod.preco}</td>
                        <td>{prod.estoque}</td>
                        <td className="actions">
                            <button>Editar</button>
                            <button>Excluir</button>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    )
}

export default TabelaProdutos